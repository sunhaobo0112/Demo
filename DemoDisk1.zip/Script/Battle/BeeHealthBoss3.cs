﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeeHealthBoss3 : EnemyHealth
{
    public override void Init()
    {
        Level = 10;
        Hp = 3000;
        Maxhp = 3000;
        Mp = 100;
        Maxmp = 100;
        Name = "古墓玉蜂boss";
        Str = 800;
        Def = 200;
        Agi = 0.1f;
        Crit = 0.15f;
        Damage = Str;
        Exp = 0;
    }

}
